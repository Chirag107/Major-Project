package com.example.project48;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class IddMainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.idd_main);
    }
}